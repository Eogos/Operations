If you use the DAC logic "DAC_extern" then you have to copy the folder "DAC" into your mission root-directory !

Wenn Du die DAC-Logik "DAC_extern" benutzt, mu�t Du den Ordner "DAC" in Dein Missionsverzeichnis kopieren !